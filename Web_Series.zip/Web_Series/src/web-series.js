import { WebSeries } from './WebSeries.js';

// customElements.define('web-series', WebSeries);
