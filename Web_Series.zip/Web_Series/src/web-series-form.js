import { html, css, LitElement } from "lit";

class webSeriesForm extends LitElement {
  // constructor() {
  //     super();
  // this.title = title;
  // this.director = director;
  // this.stars = stars;
  // this.streaming = streaming;

  // const serTitle = document.getElementById("title").content;
  // const shadowRoot = this.attachShadow({mode: 'open'})
  // .appendChild(template.cloneNode(true));

  // }

  static get properties() {
    return {
      list_arr: { type: Array },
      list_obj: { type: Object },
      list_name: { type: String },
      list_dir: { type: String },
    };
  }

  //   connectedCallback() {
  //     const template = document.querySelector('template');
  //   }
  static styles = css`
    h1 {
      text-align: center;
      padding-bottom: 20px;
      margin-bottom: 0;
      letter-spacing: 1.5px;
      word-spacing: 2px;
      text-transform: uppercase;
    }

    .collection {
      flex: 1;
      width: 45%;
      background-image: linear-gradient(rgb(223, 172, 223), rgb(216, 216, 116));
      border: 1px solid black;
      border-radius: 8px;
      margin-bottom: 40px;
      margin-right: 20px;
      display: flex;
      flex-wrap: wrap;
    }
    input,
    select,
    option {
      width: 90%;
      height: 25px;
      margin-bottom: 25px;
      margin-top: 5px;
    }
    .clkBtn {
      background-color: rgb(70, 141, 70);
      width: 100px;
      height: 40px;
      padding: 8px;
      border-radius: 5px;
      font-size: medium;
      margin-bottom: 5px;
      cursor: pointer;
    }
    .del-btn {
      background-color: rgb(189, 45, 45);
      border: 1px solid black;
      border-radius: 4px;
      width: 60px;
      align-items: center;
    }
    .flex {
      display: flex;
    }

    @media only screen and (max-width: 750px) {
      .flex {
        display: inline;
      }
      .container {
        width: 90%;
      }
      .collection {
        width: 90%;
        align-items: center;
        margin-left: 20px;
      }
      .card {
        width: 90%;
      }
    }
  `;

  //   get _serDir() {
  //     return (this.___serDir ??= this.renderRoot?.querySelector('#director') ?? null);
  //   }

  //   get _serStar() {
  //     return (this.___serStar ??= this.renderRoot?.querySelector('#stars') ?? null);
  //   }

  //   get _serStr() {
  //     return (this.___serStr ??= this.renderRoot?.querySelector('#streaming') ?? null);
  //   }
  //   get _serTitle() {
  //     return (this.___serTitle ??=
  //       this.renderRoot?.querySelector("#title").value ?? null);
  //   }

  //   get _serDir() {
  //     return (this.___serDir ??=
  //       this.renderRoot?.querySelector("#director").value ?? null);
  //   }
  constructor() {
    super();
    // this.attachShadow({mode:"open"})

    // const title = document.querySelector("#title");
    // let tilteContent = title.content;
    // const shadowRoot = this.attachShadow({mode:"open"});
    // shadowRoot.appendChild(tilteContent.cloneNode(true))
    // this.shadowRoot.appendChild(title.value.cloneNode(true))

    this.list_arr = [];
    this.list_name = "";
    this.list_dir = "";

    // this.list_obj = {
    //     a:,
    //     b:this._serDir
    // }
  }

  render() {
    return html`
      <form>
        <label for="title"><strong>Title:</strong></label
        ><br />
        <input
          type="text"
          @change="${this.handleEvent}"
          ?checked="${this.checked}"
          id="title"
        /><br /><br />
        <label for="director"><strong>Directors:</strong></label
        ><br />
        <input
          type="text"
          @change="${this.handleEvent1}"
          ?checked="${this.checked}"
          id="director"
        /><br /><br />
        <label for="stars"><strong>Stars:</strong></label
        ><br />
        <input type="text" id="stars" /><br /><br />
        <label for="streaming"><strong>Streaming on:</strong></label
        ><br />
        <select id="streaming">
          <option style="text-align: center">--- Select ---</option>
          <option value="netflix">Netflix</option>
          <option value="hotstar">Hotstar</option>
          <option value="prime">Prime</option>
          <option value="youtube">YouTube</option>
        </select>
        <br /><br />

        <p><button class="clkBtn" @click=${this._dispatchLogin}>Add</button></p>
      </form>
    `;
  }
  handleEvent(e) {
    console.log(e.target.value);
    this.list_name = e.target.value;
    console.log(this.list_name);
  }
  handleEvent1(e) {
    this.list_dir = e.target.value;
  }

  _dispatchLogin(e) {
    e.preventDefault();
    let new_obj = {
      title: "",
      director: "",
    };
    new_obj.title = this.list_name;
    new_obj.director = this.list_dir;
    this.list_arr = [...this.list_arr, new_obj];
    console.log(this.list_arr);
    localStorage.setItem("get_Data", this.list_arr)

    setTimeout(() => {
      this.list_name = "";
      this.list_dir = "";
    }, 1000);
    // this.list_arr.push(this.list_obj);
    // console.log(this.list_arr);
    // console.log(this._serTitle);
    // console.log(this.list_obj);
    const serTitle = this._serTitle;
    // const options = {
    //   detail: {  },
    //   bubbles: true,
    //   composed: true,
    // };
    console.log(new_obj);
    this.dispatchEvent(new CustomEvent("mylogin", this.list_arr));
  }
}

customElements.define("web-series-form", webSeriesForm);
