import { MyListener } from './src/MyListener.js';

window.customElements.define('my-listener', MyListener);
