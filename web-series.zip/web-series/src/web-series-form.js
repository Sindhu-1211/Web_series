import { html, css, LitElement } from "lit";

export class webSeriesForm extends LitElement {
  static get properties() {
    return {
        title: { type: String },
        director: { type: String },
        stars : {type :String},
        streaming : {type: String}
    };
  }
  static styles = css`
  :host {
    border-radius: 20px;
    background-image: linear-gradient(rgb(223, 172, 223), rgb(216, 216, 116));
    padding: 2rem;
    flex: 50%;
    border: 0.2rem solid #d6eaf8;
    display: flex;
    justify-content: space-between;
    flex-direction: column;
  }
  input,
  select,
  option {
    width: 100%;
    padding: 8px;
    border: 0.1rem solid #ccc;
    border-radius: 0.4rem;
    box-sizing: border-box;
    margin-top: 0.6rem;
    margin-bottom: 30px;
  }
  .clkBtn{
      background-color: green;
      color: white;
      padding: 8px 25px;
      border: none;
      border-radius: 5px;
      cursor: pointer;    
  }
  `;


  render() {
    return html`
      <form class="container">
        <label for="title"><strong>Title:</strong></label
        ><br />
        <input
          type="text"
          @change="${this.handleEvent}"
          ?checked="${this.checked}"
          id="title"
        /><br /><br />
        <label for="director"><strong>Directors:</strong></label
        ><br />
        <input
          type="text"
          @change="${this.handleEvent1}"
          ?checked="${this.checked}"
          id="director"
        /><br /><br />
        <label for="stars"><strong>Stars:</strong></label
        ><br />
        <input
          type="text"
          id="stars"
          @change="${this.handleEvent2}"
          ?checked="${this.checked}"
        /><br /><br />
        <label for="streaming"><strong>Streaming on:</strong></label
        ><br />
        <select
          @change="${this.handleEvent3}"
          ?checked="${this.checked}"
          id="streaming"
        >
          <option style="text-align: center">--- Select ---</option>
          <option value="netflix">Netflix</option>
          <option value="hotstar">Hotstar</option>
          <option value="prime">Prime</option>
          <option value="youtube">YouTube</option>
        </select>
        <br /><br />

        <p><button class="clkBtn" @click=${this._dispatchLogin}>Add</button></p>
      </form>
    `;
  }


  _dispatchLogin(e) {
    e.preventDefault();
    const title = this.shadowRoot.getElementById("title").value;
    const director = this.shadowRoot.getElementById("director").value;
    const stars = this.shadowRoot.getElementById("stars").value;
    const streaming = this.shadowRoot.getElementById("streaming").value;
    const serDetails = {title, director, stars, streaming};
    console.log(serDetails);

    this.dispatchEvent(new CustomEvent("mylogin", {detail:serDetails}));
  }
}

