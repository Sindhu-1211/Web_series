import { LitElement, html, css } from 'lit';

import { webSeriesForm } from "../src/web-series-form.js";
import {webSeriesOverview} from "../src/web-series-overview.js";

window.customElements.define("web-series-form", webSeriesForm);
window.customElements.define("web-series-overview", webSeriesOverview);

export class WebSeries extends LitElement {
  static get properties(){
    return {
        lists: { type: Array}
    }
}
static styles = css`
:host{
    font-family: Georgia, "Times New Roman", Times, serif;
    display:flex;
    flex-wrap: nowrap;
}
@media (max-width: 800px) {
    :host {
      display: grid;
      grid-template-columns: 1fr;
      box-sizing: border-box;
      gap: 20px;
    }
  }
`
constructor(){
super();
this.lists= "";
}
listCard(e){
console.log(e.detail)
this.lists = [...this.lists, e.detail];
console.log(this.lists)
}
render() {
    return html` 
          <web-series-form @mylogin=${this.listCard}></web-series-form>
          <web-series-overview .lists=${this.lists}></web-series-overview>
          `;
  }
}
customElements.define('web-series',WebSeries);
